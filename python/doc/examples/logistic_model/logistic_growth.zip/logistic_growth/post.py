import math as m

# reading file Y.txt
with open("Y.txt") as f:
    Y = [float(line) for line in f.readlines()]

# compute interest variables
Y_min = min(Y)
Y_max = max(Y)
Y_mean = sum(Y) / len(Y)
Y_last = Y[-1]

# writing results to output.txt
with open("output.txt", "w") as f:
    f.write("Y_min=%.17g\n" % Y_min)
    f.write("Y_max=%.17g\n" % Y_max)
    f.write("Y_mean=%.17g\n" % Y_mean)
    f.write("Y_last=%.17g\n" % Y_last)
