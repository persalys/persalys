import math as m

def logistic_solution(t, y0, a, b):
    """Computes the size of the population at time t
    according to the logistic growth model.
    Model starts at time t0 = 1790 with initial population size y0.
    
    Parameters
    ----------
    t : int
        Time (in years)
    y0 : float
        Initial population size at time t0
    a : float
        Growth rate
    b : float
        competition parameter
    
    Returns
    -------
    y : float
        Population size at time t
    """
    t0 = 1790.0
    y = a * y0 / (b * y0 + (a - b * y0) * m.exp(-a * (t - t0)))
    
    return y

# reading values of y0, a and b from file input.txt
exec(open("input.txt").read())

# computing solutions for every year between 1790 and 2011
Y = [logistic_solution(t, y0, a, b) for t in range(1790, 2011)]

# writing results to file Y.txt
with open("Y.txt", "w") as f:
    for y in Y:
        f.write("%.17g\n" % y)
